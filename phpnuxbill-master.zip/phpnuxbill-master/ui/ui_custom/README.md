# CUSTOM DESIGN

If you want to change the UI, copy the file from UI, to here, and edit as you need, so it will not be overwrite when updating

Jika mau mengubah tampilan UI, salin filenya dari folder UI kesini, lalu ubah sesuai keinginan, sehingga tidak akan ditimpa saat ada update